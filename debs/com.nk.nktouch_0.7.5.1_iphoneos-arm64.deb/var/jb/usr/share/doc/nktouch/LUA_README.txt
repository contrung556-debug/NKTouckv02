
This is Lua 5.4.9, released on 10 Aug 2026.

For installation instructions, license details, and
further information about Lua, see doc/readme.html.

